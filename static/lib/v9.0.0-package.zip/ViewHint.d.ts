declare namespace _default {
    let ANIMATING: number;
    let INTERACTING: number;
}
export default _default;
//# sourceMappingURL=ViewHint.d.ts.map